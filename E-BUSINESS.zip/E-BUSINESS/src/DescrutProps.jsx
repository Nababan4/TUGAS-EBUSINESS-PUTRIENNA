import React from 'react'

function DescrutProps({name}) {
  return (
    <h1>hai aku, {name}</h1>
  )
}

export default DescrutProps