import Belajarprops from "./Belajarprops"
import DescrutProps from "./DescrutProps"

function BelajarProps(props) {
  return (
    <div>
      <h1>hai namaku , {props.name}</h1>
    </div>
  )
}

function DestructiveProps({tinggal}) {
  return (
    <div>
      <h1>hai namaku, {tinggal}</h1>
    </div>
  )
}

function App() {
  return (
    <div>
      <BelajarProps name="Putrienna"/>
      <DestructiveProps tinggal="Maduma"/>

      <Belajarprops name="Nababan"/>
      <DescrutProps name="Boru Sasada"/>
    </div>
  )
}

export default App