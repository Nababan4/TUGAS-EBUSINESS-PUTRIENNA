function Belajarprops(props) {
  return (
    <div>
     <h1>hai aku, {props.name}</h1>
    </div>
  )
}

export default Belajarprops