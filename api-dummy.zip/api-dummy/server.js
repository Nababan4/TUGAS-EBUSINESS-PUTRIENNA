const express = require("express");
const app = express();
const PORT = 3000;

// import dummy data
let products = require("./data");

// supaya bisa baca JSON dari client
app.use(express.json());

// -------------------------------------
// CREATE DATA
// -------------------------------------
app.post("/products", (req, res) => {
  const { id, name, price } = req.body;

  // validasi sederhana
  if (!id || !name || !price) {
    return res.status(400).json({ message: "Data tidak lengkap" });
  }

  products.push({ id, name, price });
  res.status(201).json({
    message: "Produk berhasil ditambahkan",
    data: products,
  });
});

// -------------------------------------
// DELETE DATA
// -------------------------------------
app.delete("/products/:id", (req, res) => {
  const productId = parseInt(req.params.id);

  const index = products.findIndex((item) => item.id === productId);
  if (index === -1) {
    return res.status(404).json({ message: "Produk tidak ditemukan" });
  }

  products.splice(index, 1);
  res.json({
    message: "Produk berhasil dihapus",
    data: products,
  });
});

// -------------------------------------
// TEST GET ALL
// -------------------------------------
app.get("/products", (req, res) => {
  res.json(products);
});

// jalankan server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});