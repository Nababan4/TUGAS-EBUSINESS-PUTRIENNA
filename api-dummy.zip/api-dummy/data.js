// Dummy data array
let products = [
  { id: 1, name: "Kopi Hitam", price: 12000 },
  { id: 2, name: "Es Teh", price: 8000 },
];

module.exports = products;