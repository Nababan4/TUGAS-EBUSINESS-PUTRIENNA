import { useEffect, useState } from "react";

function DataAPI() {
  const [users, setUsers] = useState([]); // tempat menyimpan data dari API
  const [loading, setLoading] = useState(true);

  
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users") 
      .then((res) => res.json())
      .then((data) => {
        setUsers(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Gagal mengambil data:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <p>Memuat data...</p>;
  }

  return (
    <div>
      <h2>Daftar Nama dari API:</h2>
      <ul>
        {users.map((user) => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default DataAPI;
