function PropsNormal({ pesan }) {
  return (
    <div>
      <button onClick={() => pesan("Hallo aku kesayanganmu di masa depan")}>
        KLIK BUTTON
      </button>
    </div>
  );
}

export default PropsNormal;
