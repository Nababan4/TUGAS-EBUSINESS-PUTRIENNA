import PropsNormal from "./PropsNormal";
import DataAPI from "./DataAPI"; 

function App() {
  const handlePesan = (msg) => {
    alert(msg);
  };

  return (
    <div>
      <h1>Belajar Props & useEffect</h1>
      <PropsNormal pesan={handlePesan} />
      <hr />
      <DataAPI /> {}
    </div>
  );
}

export default App;
